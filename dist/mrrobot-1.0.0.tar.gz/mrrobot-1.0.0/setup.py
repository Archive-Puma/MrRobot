# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['mrrobot',
 'mrrobot.app',
 'mrrobot.units',
 'mrrobot.units.crypto',
 'mrrobot.units.esoteric',
 'mrrobot.units.forensics']

package_data = \
{'': ['*']}

install_requires = \
['argparse==1.4.0', 'pillow==7.0.0']

setup_kwargs = {
    'name': 'mrrobot',
    'version': '1.0.0',
    'description': 'Just another robot to automate the hacking process',
    'long_description': None,
    'author': 'Kike Fontán',
    'author_email': 'kikefontanlorenzo@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
