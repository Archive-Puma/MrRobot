class Elliot(Exception):
    pass